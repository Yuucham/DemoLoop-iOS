# DemoLoop IPA build

This project is a Capacitor iOS app. The original project had an invalid `webDir` value, so it has been corrected to `www`.

## What this workflow does

The GitHub Actions workflow builds the app on a macOS runner, without an Apple signing identity, and packages the resulting `.app` as `DemoLoop-unsigned.ipa`.

The unsigned IPA is intended to be imported into a sideloading/container workflow that can sign the guest app (for example, LiveContainer in JIT-less mode).

## Build

1. Put this project in a GitHub repository.
2. Open **Actions** → **Build DemoLoop IPA** → **Run workflow**.
3. After it completes, download the **DemoLoop-IPA** artifact.
4. Extract `DemoLoop-unsigned.ipa`.
5. Import the IPA into your chosen iOS sideload/container tool.

No Apple Developer certificate is embedded in this build.
